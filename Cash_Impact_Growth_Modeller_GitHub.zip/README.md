# Westpac Cash Impact & Growth Modeller

This interactive HTML app demonstrates how Trade and Invoice Finance improve cash flow efficiency and working capital utilisation.

## Overview
- **Stage 1: Cash Impact Analyser**
  - Calculates DIO, DSO, DPO, and CCC.
  - Shows how adjustments to receivable and payable terms free up liquidity.

- **Stage 2: Growth Impact Modeller**
  - Models how freed cash can be redeployed across staff, marketing, inventory, or capex.
  - Displays net return after finance costs.

## Hosting on GitHub Pages
1. Create a new public repository on GitHub.
2. Upload the contents of this ZIP file.
3. Rename `ccc_analyser_growth_modeller.html` to `index.html` (optional for a clean URL).
4. In repo settings, enable **GitHub Pages** → Source: `main / (root)`.
5. Your app will be available at:
   `https://yourusername.github.io/reponame/`

---
© Westpac Commercial Banking – Working Capital Solutions
